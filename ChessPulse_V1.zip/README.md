# ChessPulse V1

A first prototype of a Chess.com + Lichess improvement dashboard.

## Run it
Open `index.html` in a browser. Enter a Chess.com username and/or Lichess username.

## V1 features
- Public Chess.com profile/stats lookup
- Public Lichess profile lookup
- Recent game loading
- Combined win/loss statistics
- Basic improvement signals
- Simple rating-trend visualization
- No passwords or API tokens requested

## V2 roadmap
1. Backend account system
2. Proper OAuth where supported
3. Persistent rating history
4. Stockfish analysis
5. Blunder/mistake/inaccuracy detection
6. Opening and endgame reports
7. Time-management analysis
8. AI coach
9. Scheduled syncing
10. User-specific training plans
